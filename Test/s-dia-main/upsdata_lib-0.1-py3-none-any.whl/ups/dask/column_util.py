from functools import reduce
import operator
from typing import Any, Callable, Dict, List, Tuple, Union
from dask import dataframe as dd
import pandas as pd

from ups.dask.valid_check import valid_check_column_exists, valid_check_multiplier


def get_sigma_bounds(
    df: dd.DataFrame,
    column: str,
    multiplier: float = 3.0,
) -> Tuple[float, float]:
    """
    시그마(표준편차) 범위를 얻는 함수

    Parameters:
    -----------
    df : dask.dataframe.DataFrame
        처리할 Dask DataFrame
    column : str
        처리할 컬럼 이름
    multiplier : float, default=3
        표준편차에 곱할 배수

    Returns:
    --------
    tuple
        (lower_bound, upper_bound)

    Notes:
    ------
    - 하한 = mean - multiplier * std
    - 상한 = mean + multiplier * std
    """
    valid_check_multiplier(multiplier)

    # 평균과 표준편차 계산
    mean_val = df[column].mean().compute()
    std_val = df[column].std().compute()

    # 상한/하한 계산
    lower_bound = mean_val - multiplier * std_val
    upper_bound = mean_val + multiplier * std_val

    return (lower_bound, upper_bound)


def get_iqr_bounds(
    df: dd.DataFrame,
    column: str,
    multiplier: float = 1.5,
) -> Tuple[float, float]:
    """
    IQR(사분위수 범위) 얻는 함수

    Parameters:
    -----------
    df : dask.dataframe.DataFrame
        처리할 Dask DataFrame
    column : str
        처리할 컬럼 이름
    multiplier : float, default=1.5
        IQR에 곱할 배수

    Returns:
    --------
    tuple
        (lower_bound, upper_bound)

    Notes:
    ------
    - 하한 = Q1 - multiplier * IQR
    - 상한 = Q3 + multiplier * IQR
    - IQR = Q3 - Q1
    """
    valid_check_multiplier(multiplier)

    # Q1, Q3 계산
    q1 = df[column].quantile(0.25).compute()
    q3 = df[column].quantile(0.75).compute()

    # IQR 계산
    iqr = q3 - q1

    # 상한/하한 계산
    lower_bound = q1 - multiplier * iqr
    upper_bound = q3 + multiplier * iqr

    return (lower_bound, upper_bound)


def get_min_value_above(
    df: dd.DataFrame,
    column: str,
    threshold: Union[int, float],
) -> Union[int, float]:
    """
    지정된 값보다 크면서 가장 작은 값을 찾는 함수

    Parameters:
    -----------
    df : dask.dataframe.DataFrame
        처리할 Dask DataFrame
    column : str
        처리할 컬럼 이름
    threshold : int or float
        기준값

    Returns:
    --------
    int or float or None
        threshold보다 크면서 가장 작은 값
        조건을 만족하는 값이 없으면 None 반환
    """

    # threshold 타입 검증
    if not isinstance(threshold, (int, float)):
        raise ValueError(f'threshold는 숫자여야 합니다. {threshold}')

    # threshold보다 큰 값들만 필터링
    filtered = df[df[column] > threshold][column]

    # 값이 없으면 None 반환
    if filtered.size.compute() == 0:
        return None

    # 최솟값 반환
    return filtered.min().compute()


def get_max_value_below(
    df: dd.DataFrame,
    column: str,
    threshold: Union[int, float],
) -> Union[int, float]:
    """
    지정된 값보다 작으면서 가장 큰 값을 찾는 함수

    Parameters:
    -----------
    df : dask.dataframe.DataFrame
        처리할 Dask DataFrame
    column : str
        처리할 컬럼 이름
    threshold : int or float
        기준값

    Returns:
    --------
    int or float or None
        threshold보다 작으면서 가장 큰 값
        조건을 만족하는 값이 없으면 None 반환
    """

    # threshold 타입 검증
    if not isinstance(threshold, (int, float)):
        raise ValueError(f'threshold는 숫자여야 합니다. {threshold}')

    # threshold보다 작은 값들만 필터링
    filtered = df[df[column] < threshold][column]

    # 값이 없으면 None 반환
    if filtered.size.compute() == 0:
        return None

    # 최댓값 반환
    return filtered.max().compute()


def parse_conditions(
    df: dd.DataFrame,
    conditions: Dict[str, Any],
) -> Callable:
    """
    조건에 따른 컬럼 값 조회

    Parameters:
    -----------
    df : dask.dataframe.DataFrame
        처리할 Dask DataFrame
    conditions : Dict[str, Any]
        조건 딕셔너리
        {
            'and': [condition1, condition2, ...],
            'or': [condition1, condition2, ...],
            'ops': {
                'left': column_name,
                'op': operator,
                'right': value
            }
        }

    Returns:
    --------
    Callable
        조건을 만족하는 마스크
    """
    # print(f'parse_conditions input: {conditions}')

    # 단일 ops 조건인 경우
    if 'ops' in conditions:
        return parse_ops(df, conditions['ops'])

    # and 조건인 경우
    if 'and' in conditions:
        conditions_list = conditions['and']
        if not conditions_list:
            raise ValueError('and 조건이 비어있습니다.')
        # 첫 번째 조건으로 시작
        result = parse_conditions(df, conditions_list[0])
        # 나머지 조건들과 and 연산
        for condition in conditions_list[1:]:
            result = result & parse_conditions(df, condition)
        return result

    # or 조건인 경우
    if 'or' in conditions:
        conditions_list = conditions['or']
        if not conditions_list:
            raise ValueError('or 조건이 비어있습니다.')
        # 첫 번째 조건으로 시작
        result = parse_conditions(df, conditions_list[0])
        # 나머지 조건들과 or 연산
        for condition in conditions_list[1:]:
            result = result | parse_conditions(df, condition)
        return result

    raise ValueError('조건이 올바르지 않습니다. and, or, ops 중 하나여야 합니다.')


# def get_and(df: dd.DataFrame, conditions: List[Dict[str, Any]]) -> Callable:
#     fn = None
#     for k, v in conditions.items():
#         if k == 'and':
#             fn = lambda : get_and(df, v) if fn is None else lambda : fn() & get_and(df, v)
#         elif k == 'or':
#             fn = lambda : get_or(df, v) if fn is None else lambda : fn() & get_or(df, v)
#         elif k == 'ops':
#             fn = lambda : get_ops(df, v) if fn is None else lambda : fn() & get_ops(df, v)

#     return fn

# def get_or(df: dd.DataFrame, conditions: List[Dict[str, Any]]) -> Callable:
#     fn = None
#     for k, v in conditions.items():
#         if k == 'and':
#             fn = lambda : get_and(df, v) if fn is None else lambda : fn() | get_and(df, v)
#         elif k == 'or':
#             fn = lambda : get_or(df, v) if fn is None else lambda : fn() | get_or(df, v)
#         elif k == 'ops':
#             fn = lambda : get_ops(df, v) if fn is None else lambda : fn() | get_ops(df, v)

#     return fn

op_map = {
    '==': operator.eq,
    '!=': operator.ne,
    '>': operator.gt,
    '<': operator.lt,
    '>=': operator.ge,
    '<=': operator.le,
}


def parse_ops(df: dd.DataFrame, condition: Dict[str, str]) -> Callable:
    # print(condition)

    left = get_value(df, condition['left'])
    op = condition['op']
    right = get_value(df, condition.get('right', None))

    if op in ['==', '!=', '>', '<', '>=', '<=']:
        return op_map[op](left, right)
    if op == 'isnull':
        return left.isnull()
    if op == 'not null':
        return ~left.isnull()
    if op == 'in':
        return left.isin(right)
    if op == 'not in':
        return ~left.isin(right)
    if op == 'startswith':
        return left.str.startswith(right)
    if op == 'not startswith':
        return ~left.str.startswith(right)
    if op == 'endswith':
        return left.str.endswith(right)
    if op == 'not endswith':
        return ~left.str.endswith(right)
    if op == 'contains':
        return left.str.contains(right, case=False)
    if op == 'not contains':
        return ~left.str.contains(right, case=False)
    if op == 'match':
        return left.str.match(right, case=False)
    if op == 'not match':
        return ~left.str.match(right, case=False)

    raise ValueError('조건이 올바르지 않습니다.')


def get_value(df: dd.DataFrame, v: Union[str, int, float, List[Union[str, int, float]]]) -> Any:
    """
    DataFrame의 컬럼 값 또는 상수 값을 반환하는 함수

    Parameters:
    -----------
    df : dask.dataframe.DataFrame
        처리할 Dask DataFrame
    v : str or int or float or list
        컬럼 이름 또는 상수 값

    Returns:
    --------
    Any
        DataFrame 컬럼 또는 상수 값
    """

    if v is None:
        return None

    if isinstance(v, str) and v in df.columns:
        return df[v]

    return v
