from datetime import datetime
import logging
from pathlib import Path


# ###########################################
# get_current_time = lambda : datetime.now().strftime("%Y%m%d%H%M%S")


###########################################
def get_logger(logName: str='s-dia', logLevel: int=logging.INFO, logFile: str='./s-dia.log') -> logging.Logger:
    streamHandler = logging.StreamHandler()
    fileHandler = logging.FileHandler(Path(logFile).expanduser().resolve(), encoding='utf-8')

    logging.basicConfig(
        level=logLevel,
        datefmt='%Y-%m-%d %H:%M:%S',
        # format='%(asctime)s:%(name)s:%(levelname)s:%(message)s',
        format='%(asctime)s:%(levelname)s:%(module)s:%(funcName)s:%(lineno)d:%(message)s',
        handlers=[streamHandler, fileHandler],
    )
    logger = logging.getLogger(logName)
    return logger
